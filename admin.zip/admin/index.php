<?php
header("location:index-karir.php"); 
?>